# 児童進捗管理ツール - Kids Progress Manager

Socket.IO を使用したリアルタイム通信対応の児童進捗管理ツールです。複数のユーザーが同時に児童の学習進捗を入力・管理し、リアルタイムでデータを共有できます。

## 🚀 特徴

### リアルタイム機能
- **Socket.IO** による双方向リアルタイム通信
- **ルーム機能** - クラス単位でのデータ共有
- **コラボレーション** - 複数ユーザーでの同時編集
- **リアルタイム同期** - 生徒情報・進捗データの即時共有
- **ユーザー管理** - 参加者一覧とオンライン状態表示

### AI分析機能
- **カスタムLLM API** - 教育特化型AIモデル (meta-llama/Llama-4-Maverick-17B-128E-Instruct)
- **個別児童分析** - 学習傾向・課題・指導アドバイス
- **クラス全体分析** - 指導方針・重点課題の提案
- **リアルタイム共有** - 分析結果も他のユーザーと即座に共有

### 基本機能
- 児童情報の登録・管理
- 学習進捗データの入力・表示
- 検索・フィルター機能
- データのエクスポート・インポート
- 統計情報の表示

## 📋 システム要件

- Node.js 14.0.0 以上
- npm または yarn
- モダンブラウザ（Chrome, Firefox, Safari, Edge）

## 🛠️ セットアップ

### 1. プロジェクトのクローン
```bash
git clone <repository-url>
cd kids-progress-manager
```

### 2. 依存関係のインストール
```bash
npm install
```

### 3. サーバーの起動
```bash
# 開発モード（自動リロード）
npm run dev

# 本番モード
npm start
```

### 4. アプリケーションアクセス
ブラウザで http://localhost:3000 にアクセスしてください。

## 📡 Socket.IO 機能の使い方

### リアルタイム通信の開始

1. **接続開始**
   - サイドバーの「接続開始」ボタンをクリック
   - Socket.IOサーバーに接続されます

2. **ルーム参加**
   - ルーム名（例：「1年A組」）を入力
   - 「ルーム参加」ボタンをクリック
   - 同じルーム名のユーザー同士でデータが共有されます

3. **コラボレーション**
   - 複数のブラウザタブで同じルームに参加
   - 一方で生徒を追加すると、他方にもリアルタイムで反映されます

### 対応するリアルタイム操作

- ✅ **生徒の追加・編集・削除**
- ✅ **進捗データの入力**
- ✅ **フィールド設定の変更**
- ✅ **ユーザーの参加・退出通知**

## 🏗️ アーキテクチャ

```
├── index.html          # フロントエンドUI
├── app.js             # クライアント側JavaScript
├── server.js          # Socket.IOサーバー
├── package.json       # Node.js依存関係
└── README.md          # このファイル
```

### Socket.IO イベント

#### クライアント → サーバー
- `join_room` - ルーム参加
- `leave_room` - ルーム退出
- `sync_data` - データ同期
- `field_editing` - フィールド編集状態

#### サーバー → クライアント
- `user_joined` - ユーザー参加通知
- `user_left` - ユーザー退出通知
- `data_updated` - データ更新通知
- `active_users` - アクティブユーザー一覧

## 🔧 カスタマイズ

### ポート番号の変更
```bash
# 環境変数で指定
PORT=8080 npm start
```

### CORS設定の変更
`server.js` の cors 設定を編集してください：
```javascript
const io = socketIo(server, {
  cors: {
    origin: "https://your-domain.com",
    methods: ["GET", "POST"]
  }
});
```

## 📊 監視・管理

### 管理API
- `GET /api/stats` - 接続統計
- `GET /api/rooms` - ルーム一覧

### ログ監視
サーバーコンソールでリアルタイムアクティビティを確認できます：
```
ユーザー接続: socket_id
田中先生 がルーム 1年A組 に参加しました
データ同期: add_student by 田中先生 in room 1年A組
```

## 🚀 デプロイメント

### Heroku
```bash
# Heroku CLI のインストール後
heroku create your-app-name
git push heroku main
```

### Docker
```dockerfile
FROM node:16
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## 🔒 セキュリティ考慮事項

- プロダクション環境では適切なCORS設定を行ってください
- 認証機能の追加を検討してください
- データの永続化（データベース）を実装してください
- HTTPS/WSS を使用してください

## 🤝 コントリビューション

1. このリポジトリをフォーク
2. 機能ブランチを作成 (`git checkout -b feature/amazing-feature`)
3. 変更をコミット (`git commit -m 'Add amazing feature'`)
4. ブランチにプッシュ (`git push origin feature/amazing-feature`)
5. プルリクエストを作成

## 📝 ライセンス

このプロジェクトは MIT ライセンスの下で公開されています。

## 📞 サポート

問題や質問がある場合は、Issue を作成してください。

---

**Kids Progress Manager** - Socket.IO による革新的な児童進捗管理ツール 