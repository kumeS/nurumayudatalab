/**
 * 児童進捗管理ツール JavaScript
 * Kids Progress Manager - MVP版
 * Socket.IO リアルタイム通信対応
 */

// Socket.IO関連変数
let socket = null;
let isConnected = false;
let collaborationMode = false;
let activeUsers = new Set();
let roomId = null;

// グローバル変数
let studentsData = {};
let currentTab = 'students';
let apiKey = '';
let analysisHistory = [];

// 組み込み項目マスターデータ
const builtInFields = {
  learning: {
    category: '学習面',
    icon: 'fas fa-book',
    color: '#4f46e5',
    fields: [
      { name: '今日の理解度', type: 'select', description: '本日の授業内容の理解レベル' },
      { name: '授業参加度', type: 'select', description: '積極的な授業参加の程度' },
      { name: '小テスト結果', type: 'select', description: '小テストや確認テストの結果' },
      { name: '発表・発言', type: 'select', description: '授業中の発表や発言の積極性' },
      { name: 'ノート記録', type: 'select', description: 'ノートの取り方や記録の質' },
      { name: '集中力', type: 'select', description: '授業や作業への集中度' },
      { name: '課題完成度', type: 'select', description: '与えられた課題の完成度' },
      { name: '予習・復習', type: 'select', description: '家庭学習の取り組み状況' }
    ]
  },
  lifestyle: {
    category: '生活面',
    icon: 'fas fa-user-clock',
    color: '#10b981',
    fields: [
      { name: '身だしなみ', type: 'select', description: '服装や身だしなみの状況' },
      { name: '時間管理', type: 'select', description: '登校時間や提出期限の守り方' },
      { name: '忘れ物', type: 'checkbox', description: '必要な持ち物を忘れていないか' },
      { name: '整理整頓', type: 'select', description: '机やロッカーの整理状況' },
      { name: '健康状態', type: 'select', description: '体調や元気さの程度' },
      { name: '食事・給食', type: 'select', description: '給食や昼食の摂取状況' },
      { name: '睡眠状況', type: 'select', description: '十分な睡眠が取れているか' }
    ]
  },
  social: {
    category: '社会性・友人関係',
    icon: 'fas fa-users',
    color: '#7c3aed',
    fields: [
      { name: '友人関係', type: 'select', description: 'クラスメートとの関係性' },
      { name: '協調性', type: 'select', description: 'グループ活動での協調性' },
      { name: 'リーダーシップ', type: 'select', description: 'リーダーとしての行動力' },
      { name: '思いやり', type: 'select', description: '他者への思いやりや配慮' },
      { name: 'コミュニケーション', type: 'select', description: '適切なコミュニケーション能力' },
      { name: '問題解決', type: 'select', description: 'トラブル時の対応力' }
    ]
  },
  motivation: {
    category: '意欲・態度',
    icon: 'fas fa-fire',
    color: '#f59e0b',
    fields: [
      { name: '学習意欲', type: 'select', description: '学習に対する積極性' },
      { name: '積極性', type: 'select', description: '物事に取り組む積極的な姿勢' },
      { name: '責任感', type: 'select', description: '自分の役割を果たす責任感' },
      { name: '挑戦する姿勢', type: 'select', description: '新しいことへの挑戦意欲' },
      { name: '継続力', type: 'select', description: '最後まで取り組む継続力' },
      { name: '自主性', type: 'select', description: '自分で考えて行動する力' }
    ]
  },
  activities: {
    category: '特別活動',
    icon: 'fas fa-star',
    color: '#ef4444',
    fields: [
      { name: '委員会活動', type: 'select', description: '委員会での活動状況' },
      { name: 'クラブ活動', type: 'select', description: 'クラブや部活動への参加' },
      { name: '行事参加', type: 'select', description: '学校行事への参加度' },
      { name: '係活動', type: 'select', description: 'クラス内での係活動' },
      { name: '清掃活動', type: 'select', description: '掃除時間の取り組み' },
      { name: 'ボランティア', type: 'select', description: 'ボランティア活動への参加' }
    ]
  }
};

// DOMContentLoaded後の初期化
document.addEventListener('DOMContentLoaded', () => {
  initializeApp();
  initializeSocketIO();
  initializeAnalysisHistory();
});

/**
 * Socket.IO初期化
 */
function initializeSocketIO() {
  try {
    // Socket.IOサーバーへの接続（開発環境用）
    socket = io('http://localhost:3000', {
      autoConnect: false,
      transports: ['websocket', 'polling']
    });

    // 接続イベント
    socket.on('connect', () => {
      console.log('Socket.IO 接続成功');
      isConnected = true;
      updateConnectionStatus(true);
      showAlert('リアルタイム通信が開始されました', 'success');
    });

    // 切断イベント
    socket.on('disconnect', () => {
      console.log('Socket.IO 切断');
      isConnected = false;
      updateConnectionStatus(false);
      showAlert('リアルタイム通信が切断されました', 'warning');
    });

    // エラーイベント
    socket.on('connect_error', (error) => {
      console.error('Socket.IO 接続エラー:', error);
      isConnected = false;
      updateConnectionStatus(false);
    });

    // データ同期イベント
    socket.on('data_updated', (data) => {
      handleRemoteDataUpdate(data);
    });

    // ユーザー参加/退出イベント
    socket.on('user_joined', (userData) => {
      handleUserJoined(userData);
    });

    socket.on('user_left', (userData) => {
      handleUserLeft(userData);
    });

    // アクティブユーザー一覧更新
    socket.on('active_users', (users) => {
      updateActiveUsersList(users);
    });

    // リアルタイム編集イベント
    socket.on('field_editing', (data) => {
      handleFieldEditing(data);
    });

  } catch (error) {
    console.error('Socket.IO初期化エラー:', error);
  }
}

/**
 * Socket.IO接続開始
 */
function connectSocket() {
  if (socket && !isConnected) {
    socket.connect();
  }
}

/**
 * Socket.IO接続切断
 */
function disconnectSocket() {
  if (socket && isConnected) {
    socket.disconnect();
  }
}

/**
 * ルームに参加
 */
function joinRoom(roomName) {
  if (socket && isConnected) {
    roomId = roomName;
    socket.emit('join_room', {
      room: roomName,
      userData: {
        name: getUserName(),
        timestamp: new Date().toISOString()
      }
    });
    collaborationMode = true;
    updateCollaborationUI();
  }
}

/**
 * ルームから退出
 */
function leaveRoom() {
  if (socket && isConnected && roomId) {
    socket.emit('leave_room', { room: roomId });
    roomId = null;
    collaborationMode = false;
    activeUsers.clear();
    updateCollaborationUI();
  }
}

/**
 * データをリアルタイム同期
 */
function syncData(action, data) {
  if (socket && isConnected && collaborationMode) {
    socket.emit('sync_data', {
      room: roomId,
      action: action,
      data: data,
      timestamp: new Date().toISOString(),
      user: getUserName()
    });
  }
}

/**
 * リモートデータ更新の処理
 */
function handleRemoteDataUpdate(updateData) {
  const { action, data, user, timestamp } = updateData;
  
  // 自分が送信したデータは無視
  if (user === getUserName()) return;

  try {
    switch (action) {
      case 'add_student':
        if (!studentsData.students.find(s => s.id === data.id)) {
          studentsData.students.push(data);
          updateUI();
          showAlert(`${user}さんが生徒「${data.name}」を追加しました`, 'info');
        }
        break;
      
      case 'update_student':
        const studentIndex = studentsData.students.findIndex(s => s.id === data.id);
        if (studentIndex !== -1) {
          studentsData.students[studentIndex] = data;
          updateUI();
          showAlert(`${user}さんが生徒「${data.name}」の情報を更新しました`, 'info');
        }
        break;
      
      case 'delete_student':
        studentsData.students = studentsData.students.filter(s => s.id !== data.id);
        updateUI();
        showAlert(`${user}さんが生徒を削除しました`, 'info');
        break;
      
      case 'add_progress':
        const student = studentsData.students.find(s => s.id === data.studentId);
        if (student) {
          student.records.push(data.record);
          updateUI();
          showAlert(`${user}さんが「${student.name}」の進捗を入力しました`, 'info');
        }
        break;
      
      default:
        console.log('未知のアクション:', action);
    }
    
    saveData();
  } catch (error) {
    console.error('リモートデータ更新エラー:', error);
  }
}

/**
 * ユーザー参加の処理
 */
function handleUserJoined(userData) {
  activeUsers.add(userData.name);
  updateActiveUsersList(Array.from(activeUsers));
  showAlert(`${userData.name}さんが参加しました`, 'info');
}

/**
 * ユーザー退出の処理
 */
function handleUserLeft(userData) {
  activeUsers.delete(userData.name);
  updateActiveUsersList(Array.from(activeUsers));
  showAlert(`${userData.name}さんが退出しました`, 'info');
}

/**
 * フィールド編集状態の処理
 */
function handleFieldEditing(data) {
  const { fieldId, isEditing, user } = data;
  
  if (user === getUserName()) return;
  
  const field = document.getElementById(fieldId);
  if (field) {
    if (isEditing) {
      field.classList.add('being-edited');
      field.setAttribute('title', `${user}さんが編集中...`);
    } else {
      field.classList.remove('being-edited');
      field.removeAttribute('title');
    }
  }
}

/**
 * ユーザー名取得
 */
function getUserName() {
  let userName = localStorage.getItem('userName');
  if (!userName) {
    userName = prompt('あなたの名前を入力してください:') || `ユーザー${Math.floor(Math.random() * 1000)}`;
    localStorage.setItem('userName', userName);
  }
  return userName;
}

/**
 * 接続状態表示の更新
 */
function updateConnectionStatus(connected) {
  const statusElement = document.getElementById('connectionStatus');
  if (statusElement) {
    statusElement.innerHTML = connected 
      ? '<i class="fas fa-wifi text-success"></i> オンライン'
      : '<i class="fas fa-wifi-slash text-error"></i> オフライン';
    statusElement.className = connected ? 'status-online' : 'status-offline';
  }
}

/**
 * コラボレーションUI更新
 */
function updateCollaborationUI() {
  const collabSection = document.getElementById('collaborationSection');
  const roomInfo = document.getElementById('roomInfo');
  const activeUsersDiv = document.getElementById('activeUsers');

  if (collaborationMode && roomId) {
    if (roomInfo) roomInfo.textContent = `ルーム: ${roomId}`;
    if (collabSection) collabSection.classList.remove('hidden');
  } else {
    if (collabSection) collabSection.classList.add('hidden');
    if (activeUsersDiv) activeUsersDiv.innerHTML = '';
  }
}

/**
 * アクティブユーザー一覧更新
 */
function updateActiveUsersList(users) {
  const activeUsersDiv = document.getElementById('activeUsers');
  if (activeUsersDiv) {
    activeUsersDiv.innerHTML = users.map(user => 
      `<span class="user-badge ${user === getUserName() ? 'current-user' : ''}">${user}</span>`
    ).join('');
  }
}

/**
 * アプリケーション初期化
 */
function initializeApp() {
  loadData();
  setupEventListeners();
  
  // 保存されたタブ位置を復元（UIアップデート前に実行）
  const savedTab = localStorage.getItem('currentTab');
  currentTab = savedTab || 'students'; // デフォルトは児童管理タブ
  
  // タブ状態を即座に設定（UI更新前）
  setTabStateOnly(currentTab);
  
  updateUI();
  updateStatistics();
}

/**
 * タブ状態のみ設定（UI更新なし）
 */
function setTabStateOnly(tabName) {
  // currentTabグローバル変数も更新
  currentTab = tabName;
  
  // タブボタンの状態更新
  document.querySelectorAll('.tab').forEach(tab => {
    tab.classList.remove('active');
  });
  const targetTab = document.querySelector(`[data-tab="${tabName}"]`);
  if (targetTab) {
    targetTab.classList.add('active');
  }

  // タブコンテンツの表示切り替え
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.add('hidden');
  });
  const targetContent = document.getElementById(`${tabName}-tab`);
  if (targetContent) {
    targetContent.classList.remove('hidden');
  }
}

/**
 * イベントリスナー設定
 */
function setupEventListeners() {
  // タブ切り替え
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      switchTab(e.target.getAttribute('data-tab'));
    });
  });

  // 検索・フィルター
  document.getElementById('studentSearch').addEventListener('input', filterStudents);
  document.getElementById('gradeFilter').addEventListener('change', filterStudents);
  document.getElementById('classFilter').addEventListener('change', filterStudents);

  // フォーム送信
  document.getElementById('addStudentForm').addEventListener('submit', handleAddStudent);
  document.getElementById('addFieldForm').addEventListener('submit', handleAddField);
  document.getElementById('progressInputForm').addEventListener('submit', handleProgressInput);

  // モーダル外クリックで閉じる
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeModal(modal.id);
      }
    });
  });
}

/**
 * データ読み込み
 */
function loadData() {
  const savedData = localStorage.getItem('kidsProgressData');
  if (savedData) {
    try {
      studentsData = JSON.parse(savedData);
      // データ構造の互換性チェック
      if (!studentsData.fieldDefinitions || !studentsData.students) {
        throw new Error('Invalid data structure');
      }
    } catch (error) {
      console.error('データ読み込みエラー:', error);
      showAlert('保存データの読み込みに失敗しました。初期化します。', 'warning');
      initializeDefaultData();
    }
  } else {
    initializeDefaultData();
  }
}

/**
 * デフォルトデータ初期化
 */
function initializeDefaultData() {
  studentsData = {
    students: [],
    fieldDefinitions: [
      { id: 'taskContent', name: '実施課題', type: 'text', options: [], required: true },
      { id: 'learningStatus', name: '学習状況', type: 'select', options: ['1', '2', '3', '4', '5'], required: false },
      { id: 'motivation', name: '学習意欲', type: 'select', options: ['1', '2', '3', '4', '5'], required: false },
      { id: 'homework', name: '宿題提出', type: 'checkbox', options: [], required: false }
    ]
  };
  saveData();
}

/**
 * データ保存
 */
function saveData() {
  localStorage.setItem('kidsProgressData', JSON.stringify(studentsData));
}

/**
 * タブ切り替え
 */
function switchTab(tabName) {
  currentTab = tabName;
  
  // タブ位置をlocalStorageに保存
  localStorage.setItem('currentTab', tabName);

  // タブボタンの状態更新
  document.querySelectorAll('.tab').forEach(tab => {
    tab.classList.remove('active');
  });
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

  // タブコンテンツの表示切り替え
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.add('hidden');
  });
  document.getElementById(`${tabName}-tab`).classList.remove('hidden');

  // タブ固有の処理
  switch (tabName) {
    case 'overview':
      updateProgressTable();
      break;
    case 'input':
      updateStudentSelect();
      updateInputFields();
      break;
    case 'students':
      updateStudentsTable();
      break;
    case 'settings':
      updateFieldSettings();
      break;
  }
}

/**
 * 進捗表の更新
 */
function updateProgressTable() {
  const tbody = document.getElementById('progressTableBody');
  const thead = document.querySelector('#progressTableHead tr');
  
  // テーブルヘッダーを動的に生成
  if (thead) {
    thead.innerHTML = `
      <th style="position: sticky; left: 0; background: var(--bg-secondary); z-index: 11; box-shadow: 2px 0 4px rgba(0, 0, 0, 0.1); min-width: 120px;">氏名</th>
      <th style="min-width: 100px;">在籍番号</th>
      <th style="min-width: 80px;">学年</th>
      <th style="min-width: 80px;">クラス</th>
      ${studentsData.fieldDefinitions.map(field => 
        `<th style="min-width: 120px;">${field.name}</th>`
      ).join('')}
      <th style="min-width: 120px;">最終更新</th>
      <th style="min-width: 180px;">操作</th>
    `;
  }
  
  tbody.innerHTML = '';

  studentsData.students.forEach(student => {
    const row = createProgressTableRow(student);
    tbody.appendChild(row);
  });
}

/**
 * 進捗表の行作成（動的項目対応版）
 */
function createProgressTableRow(student) {
  const row = document.createElement('tr');
  
  // 最新のレコードを取得
  const latestRecord = student.records.length > 0 ? student.records[student.records.length - 1] : null;
  
  // 個別AI分析結果があるかチェック
  const hasAIAnalysis = latestRecord && latestRecord.aiSummary;
  
  // 操作ボタンを作成
  let actionButtons = `
    <button class="btn btn-primary" onclick="viewStudentProgress('${student.id}')" style="margin-right: 0.5rem;">
      <i class="fas fa-chart-line"></i> 履歴
    </button>
  `;
  
  // AI分析結果がある場合は詳細ボタンを追加
  if (hasAIAnalysis) {
    actionButtons += `
    <button class="btn btn-success" onclick="viewIndividualAnalysisDetail('${student.id}')" style="font-size: 0.8rem;">
      <i class="fas fa-brain"></i> AI分析詳細
    </button>
    `;
  }
  
  // 動的項目の値を生成
  const dynamicFields = studentsData.fieldDefinitions.map(field => 
    `<td>${getFieldValue(latestRecord, field.id)}</td>`
  ).join('');
  
  // 基本情報
  row.innerHTML = `
    <td class="sticky-column" style="min-width: 120px;">${student.name}</td>
    <td>${student.studentNumber}</td>
    <td>${student.grade}年生</td>
    <td>${student.class || '-'}</td>
    ${dynamicFields}
    <td>${latestRecord ? formatDate(latestRecord.timestamp) : '-'}</td>
    <td style="min-width: 180px;">
      ${actionButtons}
    </td>
  `;
  
  return row;
}

/**
 * 分析詳細表示モーダル（共通関数）
 */
function showAnalysisDetail({ title, content, analysisDate, studentName = '', type = 'overall' }) {
  // 既存のモーダルがあれば削除
  const existingModal = document.getElementById('analysisDetailModal');
  if (existingModal) {
    existingModal.remove();
  }
  
  // 新しいモーダルを作成
  const modal = document.createElement('div');
  modal.id = 'analysisDetailModal';
  modal.className = 'modal show';
  modal.innerHTML = `
    <div class="modal-content" style="max-width: 1000px; max-height: 90vh; overflow-y: auto;">
      <div class="modal-header">
        <h3 class="modal-title">${title}</h3>
        <button class="modal-close" onclick="closeAnalysisDetailModal()">&times;</button>
      </div>
      <div style="margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 1rem; background: var(--bg-secondary); border-radius: 8px; margin-bottom: 1rem;">
          <div>
            <strong style="color: var(--primary);">分析日時:</strong> ${analysisDate}
          </div>
          ${studentName ? `<div><strong style="color: var(--secondary);">対象児童:</strong> ${studentName}</div>` : ''}
          <div>
            <span class="btn ${type === 'overall' ? 'btn-primary' : 'btn-success'}" style="padding: 0.25rem 0.75rem; font-size: 0.8rem;">
              ${type === 'overall' ? '全体分析' : '個別分析'}
            </span>
          </div>
        </div>
        <div class="analysis-content analysis-content-detail" style="background: white; padding: 1.5rem; border-radius: 8px; border: 1px solid var(--border); line-height: 1.8;">
          ${formatAnalysisContent(content)}
        </div>
      </div>
      <div style="text-align: center;">
        <button class="btn btn-secondary" onclick="closeAnalysisDetailModal()">
          <i class="fas fa-times"></i> 閉じる
        </button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
}

/**
 * 分析詳細モーダルを閉じる
 */
function closeAnalysisDetailModal() {
  const modal = document.getElementById('analysisDetailModal');
  if (modal) {
    modal.remove();
  }
}

/**
 * フィールド値の取得・表示
 */
function getFieldValue(record, fieldId) {
  if (!record || !record.data || !record.data[fieldId]) {
    return '-';
  }
  
  const field = studentsData.fieldDefinitions.find(f => f.id === fieldId);
  const value = record.data[fieldId];
  
  if (field?.type === 'select') {
    return `${value}/5`;
  } else if (field?.type === 'checkbox') {
    return value ? '✓' : '✗';
  } else if (field?.type === 'text') {
    // テキストが長い場合は省略表示
    return value.length > 20 ? value.substring(0, 20) + '...' : value;
  }
  
  return value;
} 